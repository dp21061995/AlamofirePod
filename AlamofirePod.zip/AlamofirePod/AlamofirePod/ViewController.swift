
import UIKit
import Alamofire
import SwiftyJSON
import MBProgressHUD
import SDWebImage

class ViewController: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        postData()
        //getData()
        
        // cell.imgCategory.sd_setImage(objProductList[indexPath.row]["image"].stringValue, placeholder: "product_placeholder.png")
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func  getData() {
        
        /* Show Progress View */
        MBProgressHUD.showAdded(to: self.view, animated: true)
        
        Alamofire.request("https://feeds.citibikenyc.com/stations/stations.json", method: .get, parameters: ["":""], encoding: URLEncoding.default, headers: nil).responseJSON { (response:DataResponse<Any>) in
            
            /* Hide Progress View */
            MBProgressHUD.hide(for: self.view, animated: true)
            
            switch(response.result) {
            case .success(_):
                if let data = response.result.value {
                    print(data)
                    
                    let jsonResponse = JSON(data)
                    
                    print(jsonResponse)
                    
                    let loginData = Model(jsonObject:jsonResponse)
                    
                    Model.loginData = loginData
                }
                break
                
            case .failure(_):
                print(response.result.error)
                break
                
            }
        }
    }
    
    func postData()  {
        
        /* Show Progress View */
        MBProgressHUD.showAdded(to: self.view, animated: true)
        
        /*...................................*/
        //  let parameters: Parameters = [ "username" : "dp@gmail.com",
        //                             "password" : "123123" ]
        //let urlString = "https://api.harridev.com/api/v1/login"
        
        /*................[1]...................*/
        let body: NSMutableDictionary? = [
            "name": "dp",
            "phone": "6356325632"]
        
        /*.................[2]..................*/
        ////{data:[{“id”: “5”}]}
        let dict: NSMutableDictionary? = ["id": "5"]
        let arr : NSMutableArray = [dict as Any]
        let param : NSDictionary = ["data": arr]
        print(param)
        
        /*.................[3]..................*/
        let url = NSURL(string: "http://server.com" as String)
        var request = URLRequest(url: url! as URL)
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        let data = try! JSONSerialization.data(withJSONObject: body!, options: JSONSerialization.WritingOptions.prettyPrinted)
        
        let json = NSString(data: data, encoding: String.Encoding.utf8.rawValue)
        if let json = json {
            print(json)
        }
        request.httpBody = json!.data(using: String.Encoding.utf8.rawValue)
        let alamoRequest = Alamofire.request(request as URLRequestConvertible)
        alamoRequest.validate(statusCode: 200..<300)
        alamoRequest.responseString { response in
            
            /* Hide Progress View */
            MBProgressHUD.hide(for: self.view, animated: true)
            
            switch response.result {
            case .success:
                print(response.result)
            case .failure(let error):
                print(error)
            }
        }
    }
}

